import os

if __name__ == '__main__':
    os.system("pyinstaller pbrain.py pisqpipe.py --name pbrain-abpruning.exe --onefile")